function mostrarMapa(dir) {
    document.getElementById("frame").src=dir;
}